<?php
/**
 * ХуткаГрош (ЕРИП) — OpenCart 4.x
 *
 * Admin-контроллер настроек. Фабрика OpenCart 4 резолвит маршрут
 * 'extension/cmsgate_opencart_hutkigrosh/payment/hutkigrosh' в класс
 * Opencart\Admin\Controller\Extension\CmsgateOpencartHutkigrosh\Payment\Hutkigrosh.
 */
namespace Opencart\Admin\Controller\Extension\CmsgateOpencartHutkigrosh\Payment;

use esas\cmsgate\opencart\AdminControllerExtensionPayment;

require_once DIR_EXTENSION . 'cmsgate_opencart_hutkigrosh/system/library/esas/cmsgate/hutkigrosh/init.php';

class Hutkigrosh extends AdminControllerExtensionPayment
{
    public function index()
    {
        parent::index();
    }

    /**
     * Вызывается установщиком расширений (extension/payment.install).
     */
    public function install(): void
    {
        $this->load->model('setting/setting');

        $defaults = [
            'payment_hutkigrosh_status'     => '1',
            'payment_hutkigrosh_sort_order' => '2',
            'payment_hutkigrosh_sandbox'    => '1',
        ];

        $this->model_setting_setting->editSetting('payment_hutkigrosh', $defaults);
    }

    /**
     * Вызывается при удалении расширения (extension/payment.uninstall).
     */
    public function uninstall(): void
    {
        $this->load->model('setting/setting');

        $this->model_setting_setting->deleteSetting('payment_hutkigrosh');
    }
}
