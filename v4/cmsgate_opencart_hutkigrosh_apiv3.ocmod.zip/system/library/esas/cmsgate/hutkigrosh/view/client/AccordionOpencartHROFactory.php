<?php
/**
 * Фабрика аккордеона для OpenCart-обёртки ХуткаГрош.
 *
 * В релизе модуля 2.0.4 этот класс отсутствует (вызывается из
 * CompletionPanelHutkigroshOpencart::accordionBuilder() для ветки OpenCart 4,
 * но файл в поставку не попал). Восстановлен по образцу
 * esas\cmsgate\hro\accordions\AccordionHROFactory; по умолчанию используется
 * AccordionHRO_v2 — разметка bootstrap 5 (актуальная для OpenCart 4).
 */

namespace esas\cmsgate\hutkigrosh\view\client;

use esas\cmsgate\hro\accordions\AccordionHRO;
use esas\cmsgate\hro\accordions\AccordionHROFactory;
use esas\cmsgate\hro\accordions\AccordionHRO_v2;
use esas\cmsgate\hro\HROManager;

class AccordionOpencartHROFactory extends AccordionHROFactory
{
    /**
     * @return AccordionHRO
     */
    public static function findBuilder()
    {
        return HROManager::fromRegistry()->getImplementation(AccordionHRO::class, AccordionHRO_v2::class);
    }
}
