<?php
/**
 * ХуткаГрош (ЕРИП) — OpenCart 4.x
 *
 * Admin-контроллер настроек. Фабрика OpenCart 4 резолвит маршрут
 * 'extension/cmsgate_opencart_hutkigrosh/payment/hutkigrosh' в класс
 * Opencart\Admin\Controller\Extension\CmsgateOpencartHutkigrosh\Payment\Hutkigrosh.
 */
namespace Opencart\Admin\Controller\Extension\CmsgateOpencartHutkigrosh\Payment;

use esas\cmsgate\opencart\AdminControllerExtensionPayment;

require_once DIR_EXTENSION . 'cmsgate_opencart_hutkigrosh/system/library/esas/cmsgate/hutkigrosh/init.php';

class Hutkigrosh extends AdminControllerExtensionPayment
{
    public function index()
    {
        parent::index();
    }

    /**
     * AJAX-эндпоинт для загрузки метаданных (услуги, торговые точки, кассы).
     * Вызывается из формы настроек (кнопка "Актуализировать"), маршрут в OC4:
     * extension/cmsgate_opencart_hutkigrosh/payment/hutkigrosh.metadata
     */
    public function metadata(): void
    {
        $this->response->addHeader('Content-Type: application/json');
        try {
            $apiToken = isset($this->request->get['api_token_hg']) ? trim($this->request->get['api_token_hg']) : '';
            if (empty($apiToken)) {
                $this->response->setOutput(json_encode(['error' => 'API Token не указан']));
                return;
            }

            // Получаем текущие настройки sandbox из сохраненной конфигурации
            $configWrapper = \esas\cmsgate\Registry::getRegistry()->getConfigWrapper();
            $sandbox = $configWrapper->isSandbox();

            // Создаем временное хранилище с переданным токеном
            $storageArray = new \esas\cmsgate\ConfigStorageCmsArray([
                \esas\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh::apiToken() => $apiToken,
                \esas\cmsgate\ConfigFields::sandbox() => $sandbox,
                \esas\cmsgate\ConfigFields::debugMode() => false
            ]);

            $tempConfigWrapper = new \esas\cmsgate\hutkigrosh\wrappers\ConfigWrapperHutkigrosh($storageArray);
            $hg = new \esas\cmsgate\hutkigrosh\protocol\HutkigroshProtocol($tempConfigWrapper);
            $billLogin = new \esas\cmsgate\hutkigrosh\protocol\HutkigroshLoginRq();
            $hg->checkProviderMetadata($billLogin);

            $this->response->setOutput(json_encode($hg->rqProviderMetadata));

        } catch (\Throwable $e) {
            $this->response->setOutput(json_encode(['error' => $e->getMessage()]));
        } catch (\Exception $e) {
            $this->response->setOutput(json_encode(['error' => $e->getMessage()]));
        }
    }

    /**
     * Вызывается установщиком расширений (extension/payment.install).
     */
    public function install(): void
    {
        $this->load->model('setting/setting');

        $defaults = [
            'payment_hutkigrosh_status'     => '1',
            'payment_hutkigrosh_sort_order' => '2',
            'payment_hutkigrosh_sandbox'    => '1',
        ];

        $this->model_setting_setting->editSetting('payment_hutkigrosh', $defaults);
    }

    /**
     * Вызывается при удалении расширения (extension/payment.uninstall).
     */
    public function uninstall(): void
    {
        $this->load->model('setting/setting');

        $this->model_setting_setting->deleteSetting('payment_hutkigrosh');
    }
}
