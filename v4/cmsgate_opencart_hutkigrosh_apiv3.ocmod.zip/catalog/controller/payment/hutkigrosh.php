<?php
/**
 * ХуткаГрош (ЕРИП) — OpenCart 4.x
 *
 * Catalog-контроллер. В OpenCart 4 фабрика резолвит маршрут
 * 'extension/cmsgate_opencart_hutkigrosh/payment/hutkigrosh' в класс
 * Opencart\Catalog\Controller\Extension\CmsgateOpencartHutkigrosh\Payment\Hutkigrosh.
 */
namespace Opencart\Catalog\Controller\Extension\CmsgateOpencartHutkigrosh\Payment;

use esas\cmsgate\hutkigrosh\controllers\ControllerHutkigroshAddBill;
use esas\cmsgate\hutkigrosh\controllers\ControllerHutkigroshCompletionPanel;
use esas\cmsgate\hutkigrosh\controllers\ControllerHutkigroshNotify;
use esas\cmsgate\hutkigrosh\RegistryHutkigroshOpencart;
use esas\cmsgate\hutkigrosh\utils\RequestParamsHutkigrosh;
use esas\cmsgate\opencart\CatalogControllerExtensionPayment;
use esas\cmsgate\utils\Logger;
use esas\cmsgate\view\ViewBuilderOpencart;
use esas\cmsgate\wrappers\SystemSettingsWrapperOpencart;

require_once DIR_EXTENSION . 'cmsgate_opencart_hutkigrosh/system/library/esas/cmsgate/hutkigrosh/init.php';

class Hutkigrosh extends CatalogControllerExtensionPayment
{
    /**
     * Фреймворк OpenCart 4 создаёт объект Language с системным language_code (en-gb),
     * а не с языком витрины. Базовый конструктор cmsgate грузит словарь модуля напрямую
     * через $this->language->load() без указания кода — достаётся en-gb. Перезагружаем
     * словарь актуальным языком магазина, чтобы страница оплаты была на русском.
     */
    public function __construct($registry)
    {
        parent::__construct($registry);

        $this->language->load(
            'extension/cmsgate_opencart_hutkigrosh/payment/hutkigrosh',
            '',
            $this->config->get('config_language')
        );
    }

    public function index()
    {
        return parent::index();
    }

    /**
     * @param $data
     * @param $orderWrapper
     * @throws Throwable
     */
    protected function addPaySystemIndexData(&$data, $orderWrapper)
    {
        $data['confirmOrderForm'] = ViewBuilderOpencart::elementConfirmOrderForm($orderWrapper);
    }

    public function pay()
    {
        try {
            $orderId = $this->session->data['order_id'] ?? null;
            if (!isset($orderId)) {
                $this->response->redirect(SystemSettingsWrapperOpencart::getInstance()->linkCatalogCheckout());

                return false;
            }
            $orderWrapper = RegistryHutkigroshOpencart::getRegistry()->getOrderWrapper($orderId);
            // проверяем, привязан ли к заказу billid, если да,
            // то счет не выставляем, а просто прорисовываем страницу
            $billJustAdded = false;
            if (empty($orderWrapper->getExtId())) {
                $controller = new ControllerHutkigroshAddBill();
                $controller->process($orderWrapper);
                $billJustAdded = true;
            }
            $controller = new ControllerHutkigroshCompletionPanel();
            $completionPanel = $controller->process($orderId);
            // При успешном выставлении счёта очищаем корзину (как checkout/success),
            // чтобы товары не оставались в корзине и не давали оформить повторно.
            // order_id намеренно НЕ сбрасываем — он нужен для отображения страницы оплаты при перезагрузке.
            if ($billJustAdded) {
                $this->cart->clear();
                unset($this->session->data['shipping_method']);
                unset($this->session->data['shipping_methods']);
                unset($this->session->data['payment_method']);
                unset($this->session->data['payment_methods']);
                unset($this->session->data['guest']);
                unset($this->session->data['comment']);
                unset($this->session->data['coupon']);
                unset($this->session->data['reward']);
                unset($this->session->data['voucher']);
                unset($this->session->data['vouchers']);
                unset($this->session->data['totals']);
            }
            $data['completionPanel'] = $completionPanel;
            $this->document->setTitle($this->language->get('heading_title'));
            $this->addCommon($data);
            $this->addCheckoutContinueButton($data);
            $this->response->setOutput(
                $this->load->view(
                    $this->getView('hutkigrosh_checkout_success'), $data));
        } catch (\Throwable $e) {
            return $this->redirectFailure('pay', $e);
        } catch (\Exception $e) { // для совместимости с php 5
            return $this->redirectFailure('pay', $e);
        }
    }

    /**
     * Переопределено: при ошибке сервиса (напр. "счёт не уникальный") возвращаем пользователя
     * на оформление заказа с новым order_id и дружелюбным сообщением вместо сырой ошибки.
     */
    protected function redirectFailure($loggerName, $ex)
    {
        Logger::getLogger($loggerName)->error('Exception:', $ex);
        // Сбрасываем order_id, чтобы при повторном оформлении создался новый заказ
        // (новый уникальный invId), иначе сервис снова отклонит как неуникальный.
        unset($this->session->data['order_id']);
        // Дружелюбное сообщение вместо сырой ошибки сервиса.
        $this->session->data['error'] = 'Обратитесь к администратору сервиса';
        $url = SystemSettingsWrapperOpencart::getInstance()->linkCatalogCheckout();
        // фиксируем, был ли вывод в поток до редиректа и откуда именно
        $hsFile = '';
        $hsLine = 0;
        $headersSent = headers_sent($hsFile, $hsLine);
        @file_put_contents(DIR_STORAGE . 'logs/redirect_diag.log',
            date('Y-m-d H:i:s') . ' hutkigrosh headers_sent=' . ($headersSent ? "YES @ $hsFile:$hsLine" : 'NO')
            . ' ob_level=' . ob_get_level() . ' last_error=' . json_encode(error_get_last()) . "\n", FILE_APPEND);
        if (!$headersSent) {
            // Чистый путь: штатный 302-редирект.
            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            $this->response->redirect($url);
        }
        // Headers уже отправлены (какой-то вывод успел уйти в поток) — 302 невозможен.
        // Делаем клиентский редирект через HTML, чтобы пользователь всё равно попал
        // на оформление заказа и увидел сообщение.
        echo '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8">'
           . '<meta http-equiv="refresh" content="0; url=' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">'
           . '<title>Перенаправление</title></head><body style="font-family:sans-serif;padding:24px">'
           . '<p>Обратитесь к администратору сервиса.</p>'
           . '<p><a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">Перейти к оформлению заказа</a></p>'
           . '<script>window.location.replace(' . json_encode($url) . ');</script>'
           . '</body></html>';
        exit;
    }

    public function notify()
    {
        try {
            $billId = $this->request->get[RequestParamsHutkigrosh::PURCHASE_ID];
            $controller = new ControllerHutkigroshNotify();
            $controller->process($billId);
        } catch (\Throwable $e) {
            Logger::getLogger('notify')->error('Exception:', $e);
        } catch (\Exception $e) { // для совместимости с php 5
            Logger::getLogger('notify')->error('Exception:', $e);
        }
    }
}
