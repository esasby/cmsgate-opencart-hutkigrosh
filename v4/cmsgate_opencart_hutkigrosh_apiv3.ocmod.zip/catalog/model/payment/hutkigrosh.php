<?php
/**
 * ХуткаГрош (ЕРИП) — OpenCart 4.x
 *
 * Catalog-модель. В OpenCart 4 метод получения способов оплаты
 * называется getMethods (множественное число) и возвращает массив
 * {code, name, option[], sort_order}.
 */
namespace Opencart\Catalog\Model\Extension\CmsgateOpencartHutkigrosh\Payment;

use esas\cmsgate\opencart\ModelExtensionPayment;

require_once DIR_EXTENSION . 'cmsgate_opencart_hutkigrosh/system/library/esas/cmsgate/hutkigrosh/init.php';

class Hutkigrosh extends ModelExtensionPayment
{
    /**
     * Точка входа OpenCart 4: checkout/payment_method вызывает getMethods($address).
     * Родительский getMethod для ветки v4_x уже возвращает нужный формат.
     */
    public function getMethods(array $address = []): array
    {
        // статус включён?
        if (!$this->config->get('payment_hutkigrosh_status')) {
            return [];
        }

        return $this->getMethod($address, 0);
    }
}
