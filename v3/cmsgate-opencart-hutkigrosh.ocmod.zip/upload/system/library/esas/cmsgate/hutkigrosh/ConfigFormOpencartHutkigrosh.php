<?php

namespace esas\cmsgate\hutkigrosh;

use esas\cmsgate\Registry;
use esas\cmsgate\view\admin\ConfigFormOpencart;
use esas\cmsgate\view\admin\fields\ConfigFieldHidden;

class ConfigFormOpencartHutkigrosh extends ConfigFormOpencart
{
    public function generate()
    {
        $html = parent::generate();
        $html .= $this->generateMetadataScript();
        return $html;
    }

    /**
     * Скрытое поле провайдер-метаданных хранится в БД как JSON, а в форму отдается в base64url.
     * Значение читаем напрямую из хранилища (а не через getValue(), который на повторном рендере
     * формы после ошибки валидации вернул бы отправленный base64url и привел бы к двойному кодированию).
     */
    public function generateHiddenField(ConfigFieldHidden $configField)
    {
        $raw = Registry::getRegistry()->getConfigWrapper()->get($configField->getKey());
        $value = self::base64urlEncode((string)$raw);
        return '<input type="hidden" name="' . $configField->getKey() . '" value="' . htmlspecialchars($value, ENT_QUOTES) . '" />';
    }

    /**
     * Перед сохранением декодируем base64url из скрытого поля обратно в JSON.
     */
    public function save()
    {
        $key = ConfigFieldsHutkigrosh::providerMetadata();
        if (isset($_REQUEST[$key])) {
            $decoded = self::base64urlDecode($_REQUEST[$key]);
            if ($decoded !== null) {
                $_REQUEST[$key] = $decoded;
            }
        }
        parent::save();
    }

    /**
     * base64url-кодирование (URL-safe, без паддинга).
     */
    private static function base64urlEncode($s)
    {
        return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
    }

    /**
     * base64url-декодирование. Возвращает null при невозможности декодировать.
     */
    private static function base64urlDecode($s)
    {
        if ($s === null || $s === '') {
            return '';
        }
        $s = strtr($s, '-_', '+/');
        $pad = strlen($s) % 4;
        if ($pad) {
            $s .= str_repeat('=', 4 - $pad);
        }
        $decoded = base64_decode($s, true);
        return $decoded === false ? null : $decoded;
    }

    private function generateMetadataScript()
    {
        // Сохраненные значения селектов (отдельные настройки) — для восстановления выбора при открытии
        $cfg = Registry::getRegistry()->getConfigWrapper();
        $saved = array(
            'service' => $cfg->get(ConfigFieldsHutkigrosh::serviceId()),
            'outlet'  => $cfg->get(ConfigFieldsHutkigrosh::retailOutletId()),
            'cashbox' => $cfg->get(ConfigFieldsHutkigrosh::cashboxId()),
        );
        $savedJson = json_encode($saved);

        $js = <<<'JS'
<script>
(function () {
    var SAVED = __SAVED_JSON__;

    // Формируем URL для AJAX-загрузки метаданных из текущего URL страницы
    var metadataUrl = window.location.href.replace(/route=[^&]+/, 'route=extension/payment/hutkigrosh/metadata');

    // Элементы формы ищем по суффиксу name (префикс настроек модуля от CMS)
    var $tokenInput = $('input[name$="_hg_api_token"]');
    var $selectServices = $('select[name$="_service_id"]');
    var $selectOutlets = $('select[name$="_retail_outlet_id"]');
    var $selectCashboxes = $('select[name$="_cash_box_id"]');
    var $metaInput = $('input[name$="_provider_metadata"]');

    if (!$tokenInput.length) return;

    var globalData = null;

    // base64url кодирование/декодирование (UTF-8-безопасно)
    function b64urlEncode(str) {
        return btoa(unescape(encodeURIComponent(str)))
            .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    }
    function b64urlDecode(str) {
        str = String(str).replace(/-/g, '+').replace(/_/g, '/');
        while (str.length % 4) str += '=';
        return decodeURIComponent(escape(atob(str)));
    }

    // Кнопка "Актуализировать"
    var $tokenGroup = $tokenInput.closest('.form-group');
    var $refreshBtnGroup = $('<div class="form-group">' +
        '<label class="col-sm-2 control-label">&nbsp;</label>' +
        '<div class="col-sm-10">' +
        '<button id="hg_refresh_btn" type="button" class="btn btn-primary">' +
        '<i class="fa fa-refresh"></i> Актуализировать</button></div></div>');
    $tokenGroup.after($refreshBtnGroup);
    var $refreshBtn = $('#hg_refresh_btn');

    function findOutlet(data, code) {
        if (!data || !data.retailOutlets) return null;
        for (var i = 0; i < data.retailOutlets.length; i++) {
            if (String(data.retailOutlets[i].code) === String(code)) return data.retailOutlets[i];
        }
        return null;
    }

    // Рендер опций в select, восстанавливая выбранное значение
    function renderOptions($el, items, savedValue) {
        var html = '';
        if (items && items.length > 0) {
            for (var i = 0; i < items.length; i++) {
                var selected = (String(items[i].code) === String(savedValue)) ? ' selected' : '';
                html += '<option value="' + items[i].code + '"' + selected + '>' + items[i].name + '</option>';
            }
        } else {
            html = '<option value="">—</option>';
        }
        $el.html(html);
    }

    // Заполнение селектов из объекта метаданных + восстановление сохраненного выбора
    function applyData(data) {
        if (!data) return;
        globalData = data;
        renderOptions($selectServices, data.services, SAVED.service);
        renderOptions($selectOutlets, data.retailOutlets, SAVED.outlet);
        // Кассы привязаны к торговой точке (сохраненной, иначе первой)
        var outlet = findOutlet(data, SAVED.outlet) || (data.retailOutlets && data.retailOutlets[0]) || null;
        if (outlet && outlet.cashBoxes) {
            renderOptions($selectCashboxes, outlet.cashBoxes, SAVED.cashbox);
        }
        $selectServices.add($selectOutlets).add($selectCashboxes).prop('disabled', false);
    }

    // При открытии страницы: заполняем селекты из скрытого поля (без обращения к API)
    var raw = $metaInput.val();
    if (raw) {
        try {
            applyData(JSON.parse(b64urlDecode(raw)));
        } catch (e) {
            // Битые данные игнорируем — селекты останутся пустыми до "Актуализировать"
        }
    }

    // "Актуализировать": запрос к API, запись base64url(JSON) в скрытое поле
    function loadMetadata() {
        var token = $tokenInput.val().trim();
        if (!token) { alert('Введите API Token'); return; }
        var $allSelects = $selectServices.add($selectOutlets).add($selectCashboxes);
        $refreshBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Загрузка...');
        $allSelects.prop('disabled', true).html('<option value="">Загрузка...</option>');
        $.ajax({
            url: metadataUrl,
            type: 'GET',
            dataType: 'json',
            data: { api_token_hg: token },
            success: function (data) {
                if (data && typeof data.error === 'undefined' && typeof data.message === 'undefined') {
                    $metaInput.val(b64urlEncode(JSON.stringify(data)));
                    applyData(data);
                } else {
                    var msg = 'Ошибка API';
                    if (data && data.message) msg = data.message;
                    if (data && data.error) msg = data.error;
                    alert(msg);
                    $allSelects.prop('disabled', true).html('<option value="">—</option>');
                }
            },
            error: function () {
                alert('Ошибка соединения с сервером');
                $allSelects.prop('disabled', true).html('<option value="">—</option>');
            },
            complete: function () {
                $refreshBtn.prop('disabled', false).html('<i class="fa fa-refresh"></i> Актуализировать');
            }
        });
    }

    $refreshBtn.on('click', loadMetadata);

    // При смене торговой точки — обновляем список касс
    $selectOutlets.on('change', function () {
        if (!globalData) return;
        var outlet = findOutlet(globalData, $(this).val());
        if (outlet && outlet.cashBoxes) {
            renderOptions($selectCashboxes, outlet.cashBoxes, SAVED.cashbox);
        }
    });
})();
</script>
JS;
        return str_replace('__SAVED_JSON__', $savedJson, $js);
    }
}
