<?php

use esas\cmsgate\opencart\AdminControllerExtensionPayment;

require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/system/library/esas/cmsgate/hutkigrosh/init.php');

class ControllerExtensionPaymentHutkiGrosh extends AdminControllerExtensionPayment
{

    /**
     * ControllerExtensionPaymentHutkiGrosh constructor.
     */
    public function index()
    {
        parent::index();
    }

    /**
     * AJAX-эндпоинт для загрузки метаданных (услуги, торговые точки, кассы)
     */
    public function metadata()
    {
        $this->response->addHeader('Content-Type: application/json');
        try {
            $apiToken = isset($this->request->get['api_token_hg']) ? trim($this->request->get['api_token_hg']) : '';
            if (empty($apiToken)) {
                $this->response->setOutput(json_encode(['error' => 'API Token не указан']));
                return;
            }

            // Получаем текущие настройки sandbox из сохраненной конфигурации
            $configWrapper = \esas\cmsgate\Registry::getRegistry()->getConfigWrapper();
            $sandbox = $configWrapper->isSandbox();

            // Создаем временное хранилище с переданным токеном
            $storageArray = new \esas\cmsgate\ConfigStorageCmsArray([
                \esas\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh::apiToken() => $apiToken,
                \esas\cmsgate\ConfigFields::sandbox() => $sandbox,
                \esas\cmsgate\ConfigFields::debugMode() => false
            ]);

            $tempConfigWrapper = new \esas\cmsgate\hutkigrosh\wrappers\ConfigWrapperHutkigrosh($storageArray);
            $hg = new \esas\cmsgate\hutkigrosh\protocol\HutkigroshProtocol($tempConfigWrapper);
            $billLogin = new \esas\cmsgate\hutkigrosh\protocol\HutkigroshLoginRq();
            $hg->checkProviderMetadata($billLogin);

            $this->response->setOutput(json_encode($hg->rqProviderMetadata));

        } catch (\Throwable $e) {
            $this->response->setOutput(json_encode(['error' => $e->getMessage()]));
        } catch (\Exception $e) {
            $this->response->setOutput(json_encode(['error' => $e->getMessage()]));
        }
    }
}
