<?php

namespace esas\cmsgate\hutkigrosh;

use esas\cmsgate\view\admin\ConfigFormOpencart;

class ConfigFormOpencartHutkigrosh extends ConfigFormOpencart
{
    public function generate()
    {
        $html = parent::generate();
        $html .= $this->generateMetadataScript();
        return $html;
    }

    private function generateMetadataScript()
    {
        return <<<'HTML'
<script>
(function() {
    // Формируем URL для AJAX-загрузки метаданных из текущего URL страницы
    var metadataUrl = window.location.href.replace(/route=[^&]+/, 'route=extension/payment/hutkigrosh/metadata');

    // Ищем элементы по name-атрибуту (надежнее, чем по ID)
    var $tokenInput = $('input[name$="_hg_api_token"]');
    var $selectServices = $('select[name$="_service_id"]');
    var $selectOutlets = $('select[name$="_retail_outlet_id"]');
    var $selectCashboxes = $('select[name$="_cash_box_id"]');

    if (!$tokenInput.length) return;

    var globalData = null;

    // Сохраняем текущие (сохраненные) значения селектов
    var savedService = $selectServices.val();
    var savedOutlet = $selectOutlets.val();
    var savedCashbox = $selectCashboxes.val();

    // Добавляем кнопку загрузки после поля API Token
    var $tokenGroup = $tokenInput.closest('.form-group');
    var $refreshBtnGroup = $('<div class="form-group">' +
        '<label class="col-sm-2 control-label">&nbsp;</label>' +
        '<div class="col-sm-10">' +
        '<button id="hg_refresh_btn" type="button" class="btn btn-primary">' +
        '<i class="fa fa-refresh"></i> Загрузить данные' +
        '</button>' +
        '</div></div>');
    $tokenGroup.after($refreshBtnGroup);
    var $refreshBtn = $('#hg_refresh_btn');

    // Функция рендеринга опций в select
    function renderOptions($el, items, savedValue) {
        var html = '';
        if (items && items.length > 0) {
            for (var i = 0; i < items.length; i++) {
                var selected = (String(items[i].code) === String(savedValue)) ? ' selected' : '';
                html += '<option value="' + items[i].code + '"' + selected + '>' + items[i].name + '</option>';
            }
        } else {
            html = '<option value="">—</option>';
        }
        $el.html(html);
    }

    // Загрузка метаданных
    function loadMetadata() {
        var token = $tokenInput.val().trim();
        if (!token) return;

        var $allSelects = $selectServices.add($selectOutlets).add($selectCashboxes);
        $refreshBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Загрузка...');
        $allSelects.prop('disabled', true).html('<option value="">Загрузка...</option>');

        $.ajax({
            url: metadataUrl,
            type: 'GET',
            dataType: 'json',
            data: { api_token_hg: token },
            success: function(data) {
                if (data && typeof data.error === 'undefined' && typeof data.message === 'undefined') {
                    globalData = data;
                    renderOptions($selectServices, data.services, savedService);
                    renderOptions($selectOutlets, data.retailOutlets, savedOutlet);
                    // Кассы привязаны к торговой точке
                    if (data.retailOutlets && data.retailOutlets.length > 0) {
                        var outlet = null;
                        for (var i = 0; i < data.retailOutlets.length; i++) {
                            if (String(data.retailOutlets[i].code) === String(savedOutlet)) {
                                outlet = data.retailOutlets[i];
                                break;
                            }
                        }
                        if (!outlet) outlet = data.retailOutlets[0];
                        if (outlet.cashBoxes) {
                            renderOptions($selectCashboxes, outlet.cashBoxes, savedCashbox);
                        }
                    }
                    $allSelects.prop('disabled', false);
                } else {
                    var msg = 'Ошибка API';
                    if (data && data.message) msg = data.message;
                    if (data && data.error) msg = data.error;
                    alert(msg);
                    $allSelects.prop('disabled', true).html('<option value="">—</option>');
                }
            },
            error: function() {
                alert('Ошибка соединения с сервером');
                $allSelects.prop('disabled', true).html('<option value="">—</option>');
            },
            complete: function() {
                $refreshBtn.prop('disabled', false).html('<i class="fa fa-refresh"></i> Загрузить данные');
            }
        });
    }

    // Обработчик кнопки
    $refreshBtn.on('click', function() {
        var token = $tokenInput.val().trim();
        if (!token) {
            alert('Введите API Token');
            return;
        }
        loadMetadata();
    });

    // При смене торговой точки — обновляем список касс
    $selectOutlets.on('change', function() {
        if (!globalData || !globalData.retailOutlets) return;
        var selectedCode = $(this).val();
        var outlet = null;
        for (var i = 0; i < globalData.retailOutlets.length; i++) {
            if (String(globalData.retailOutlets[i].code) === String(selectedCode)) {
                outlet = globalData.retailOutlets[i];
                break;
            }
        }
        if (outlet && outlet.cashBoxes) {
            renderOptions($selectCashboxes, outlet.cashBoxes, savedCashbox);
        }
    });

    // Автозагрузка при наличии сохраненного токена
    if ($tokenInput.val().trim()) {
        loadMetadata();
    }
})();
</script>
HTML;
    }
}
