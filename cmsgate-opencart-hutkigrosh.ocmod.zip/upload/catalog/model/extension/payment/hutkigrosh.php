<?php

use esas\cmsgate\opencart\ModelExtensionPayment;

require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/system/library/esas/cmsgate/init.php');
class ModelExtensionPaymentHutkigrosh extends ModelExtensionPayment
{

}