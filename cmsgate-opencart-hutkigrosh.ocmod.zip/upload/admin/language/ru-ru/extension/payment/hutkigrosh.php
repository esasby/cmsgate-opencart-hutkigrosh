<?php

$_['heading_title'] = 'HutkiGrosh';

$_['text_hutkigrosh'] = '<img src="view/image/payment/hgrosh.png" alt="Расчёт (ЕРИП)" title="Расчёт (ЕРИП)" style="border: 1px solid #EEEEEE;" />';
$_['text_success'] = 'Настройки модуля обновлены!';

$_['text_status'] = 'Статус:';
$_['text_enabled'] = 'Включено';
$_['text_disabled'] = 'Отключено';
$_['text_save'] = 'Сохранить';
$_['text_cancel'] = 'Отмена';

// Error
$_['error_permission'] = 'Внимание: у вас нет прав для редактирования модуля оплаты!';