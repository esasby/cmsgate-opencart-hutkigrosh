<?php

$_['heading_title'] = 'HutkiGrosh';

$_['text_hutkigrosh'] = '<img src="view/image/payment/hgrosh.png" alt="Hutkigrosh" title="Hutkigrosh" style="border: 1px solid #EEEEEE;" />';
$_['text_success'] = 'Module settings have been updated!';


$_['text_status'] = 'Status:';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_save'] = 'Save';
$_['text_cancel'] = 'Cancel';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the payment module!';